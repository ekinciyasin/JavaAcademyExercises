package datatypesvariables;

public class DataTypes {
    public static void main(String[] args) {


        char initial1 = 'Y';
        char initial2 = 'E';

        int populationGermany = 83000000;

        long populationEarth = 7800000000L;

        boolean isDaytime = true;

        double gomezGoalStrikeQuote = 2;

        byte javaProgramLengthWeeks = 12;

        float pi = 3.14159f;


        System.out.println("1. Yasin Ekinci Initials: " + initial1 + initial2);
        System.out.println("2. Population in Germany: " + populationGermany);
        System.out.println("3. Population on Earth: " + populationEarth);
        System.out.println("4. Is currently daytime?: " + isDaytime);
        System.out.println("5. Goal strike quote of Mario Gomez at Bayern München: " + gomezGoalStrikeQuote);
        System.out.println("6. Length of the Java program in weeks: " + javaProgramLengthWeeks);
        System.out.println("7. The mathematical number PI: " + pi);
    }
}
