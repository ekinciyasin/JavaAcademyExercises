package inputoutput;

public class FormattingTextOutput {
    public static void main(String[] args) {
        System.out.println("|\\---/|");
        System.out.println("| o_o |");
        System.out.println(" \\_^_/");
    }
}
