package operators;

public class OneLineCode {
    public static void main(String[] args) {
        System.out.println((Math.sqrt(3.5 + 15.5) * 5 / 3) - ((15.5 + 10) * (15.5 - 4.1)));;
    }
}
